Our client, Alex Jaimes Castillo, is a Swinburne University of Technology postgraduate researcher and social enterprise Manatzura. He is working on a project for sustainable waste management technologies and specifically the LIDA (Live Interactions and Dynamic Activities) system, a smart, in-vessel composting prototype designed to simplify composting through automation and sensor technology. The current status of the project updated in the source files that were given by the Alex. 

Our team is allocated with updating and enhancing the current version of the mobile app part of the project. There will be 2 other teams that collaborating with us to develop this project who are allocated to enchance the mechanical and mechatronics parts. 

# Team allocation

Currently we got 4 members in our group.

    Senupama Damdini Deshapriya     104329709
    Chrishelle Anthoneyz            104067504
    Haritha Manuja Perera           104207449
    Thenura Dulnath Kuruppuarachchi 103512993

other two teams can be listed as below.

     Team 1
      Saad zaheen           104746418
      Hamza Waheed          104202004
      Syed Muhammad Taseen  104491815
      Hashim Abbasi         104821386
and next one

      Team 2
      Ratanakvisal Heng        103808139
      Araf Hossain             103813308
      Arunchakrey Puthyrith    104348076
      Saad Ibn Jamil           103837887
      Sokpheakkdey Tith        104178189
